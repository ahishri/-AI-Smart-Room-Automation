import streamlit as st
import joblib
import pandas as pd
from pathlib import Path

st.set_page_config(page_title="AI Smart Room Monitoring", page_icon="🏠")
st.title("🏠 AI-Based Smart Room Monitoring")
st.write("Enter sensor readings to predict the room risk level.")

MODEL_PATH = Path(__file__).parent / "smart_room_random_forest.pkl"

@st.cache_resource
def load_model():
    return joblib.load(MODEL_PATH)

if not MODEL_PATH.exists():
    st.error("Place smart_room_random_forest.pkl in the same folder as app.py, then restart the app.")
    st.stop()

try:
    model = load_model()
except Exception as e:
    st.error(f"Could not load model: {e}")
    st.stop()

st.subheader("Sensor Readings")
temperature = st.number_input("Temperature (°C)", min_value=-20.0, max_value=100.0, value=31.3, step=0.1)
humidity = st.number_input("Humidity (%)", min_value=0.0, max_value=100.0, value=50.0, step=0.1)
gas = st.number_input("MQ-2 Gas Reading", min_value=0, max_value=1023, value=123, step=1)

if st.button("Predict Risk Level", type="primary", use_container_width=True):
    values = pd.DataFrame(
        [[temperature, humidity, gas]],
        columns=["Temperature", "Humidity", "Gas"]
    )
    try:
        result = str(model.predict(values)[0]).upper()
        st.subheader("Prediction Result")
        if result == "LOW":
            st.success("LOW RISK")
        elif result == "MEDIUM":
            st.warning("MEDIUM RISK")
        elif result == "HIGH":
            st.error("HIGH RISK")
        else:
            st.info(f"Predicted class: {result}")
        st.write("Values submitted:")
        st.dataframe(values, use_container_width=True)
    except Exception as e:
        st.error(f"Prediction failed: {e}")
        st.info("Check that the model was trained with Temperature, Humidity, and Gas in this order.")

st.divider()
st.caption("Educational demonstration only. The model was trained using simulated data. This website does not directly connect to Arduino or control the relay/buzzer.")
