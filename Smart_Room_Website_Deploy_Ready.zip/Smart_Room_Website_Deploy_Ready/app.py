import streamlit as st
import joblib
import pandas as pd
from pathlib import Path

st.set_page_config(page_title="AI Smart Room Monitoring", page_icon="🏠")
st.title("🏠 AI-Based Smart Room Monitoring")
st.write("Enter the readings below to predict the room risk level.")

MODEL_PATH = Path(__file__).parent / "smart_room_random_forest.pkl"

@st.cache_resource
def load_model():
    return joblib.load(MODEL_PATH)

if not MODEL_PATH.exists():
    st.error("The model file smart_room_random_forest.pkl must be in the same folder as app.py.")
    st.stop()

try:
    model = load_model()
except Exception as e:
    st.error(f"Could not load model: {e}")
    st.stop()

st.subheader("Sensor readings")
temperature = st.number_input("Temperature (°C)", min_value=-20.0, max_value=100.0, value=31.3, step=0.1)
humidity = st.number_input("Humidity (%)", min_value=0.0, max_value=100.0, value=50.0, step=0.1)
gas = st.number_input("MQ-2 gas reading", min_value=0, max_value=1023, value=123, step=1)

st.subheader("Additional model inputs")
st.caption("Your uploaded model was trained with Dust and Flame inputs too. Since your current hardware does not include these sensors, enter values manually. Use the same scale used in your training dataset.")
dust = st.number_input("Dust reading", min_value=0, max_value=1023, value=0, step=1)
flame = st.selectbox("Flame reading", options=[0, 1], format_func=lambda x: "0 — No flame detected" if x == 0 else "1 — Flame detected")

if st.button("Predict risk level", type="primary", use_container_width=True):
    values = pd.DataFrame(
        [[temperature, humidity, gas, dust, flame]],
        columns=["Temperature", "Humidity", "Gas", "Dust", "Flame"]
    )
    try:
        result = str(model.predict(values)[0]).upper()
        st.subheader("Prediction result")
        if result == "LOW":
            st.success("LOW RISK")
        elif result == "MEDIUM":
            st.warning("MEDIUM RISK")
        elif result == "HIGH":
            st.error("HIGH RISK")
        else:
            st.info(f"Predicted class: {result}")
        st.write("Values used for prediction:")
        st.dataframe(values, use_container_width=True)
    except Exception as e:
        st.error(f"Prediction failed: {e}")

st.divider()
st.caption("Educational demonstration only. The model was trained using simulated data. Dust and Flame are manually entered because those sensors are not part of the current hardware. This website does not directly connect to Arduino or control the relay/buzzer. Do not use it as a fire or gas safety system.")
