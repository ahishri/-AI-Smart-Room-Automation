# Smart Room Risk Prediction Website

## Files
- `app.py` — Streamlit website
- `requirements.txt` — Python dependencies (scikit-learn pinned to the model's saved version)
- `smart_room_random_forest.pkl` — Random Forest model

## Publish online with Streamlit Community Cloud
1. Sign in to GitHub and create a new repository (private is fine).
2. Upload all three files (`app.py`, `requirements.txt`, and `smart_room_random_forest.pkl`) to the repository's root folder.
3. Visit https://share.streamlit.io/ and sign in with GitHub.
4. Choose **Create app**, select your repository, branch `main`, and main file `app.py`.
5. Click **Deploy**. Streamlit will provide your website URL.

## Run locally
Install Python, open a terminal in this folder, and run:

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Important model note
The uploaded model expects five features in this order: `Temperature`, `Humidity`, `Gas`, `Dust`, `Flame`. The current hardware list has DHT22 and MQ-2 only, so the website asks the user to enter Dust and Flame values manually. Use the same scales/encoding used in the training dataset. The website is an educational demonstration based on simulated training data, not a certified fire/gas safety system. It does not connect directly to Arduino or control the relay/buzzer.
